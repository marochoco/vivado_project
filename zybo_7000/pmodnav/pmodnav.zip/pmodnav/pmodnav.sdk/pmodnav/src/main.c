#include <stdio.h>
#include "platform.h"
#include "xparameters.h"
#include "xil_io.h"
#include "sleep.h"

// コンパイラの指摘通り、IP付きの定義名に修正
#define PMOD_NAV_BASE XPAR_PMODNAV_IP_0_S00_AXI_BASEADDR

// レジスタオフセット
#define REG_FIXED_AX (PMOD_NAV_BASE + 32)
#define REG_FIXED_AY (PMOD_NAV_BASE + 36)
#define REG_FIXED_AZ (PMOD_NAV_BASE + 40)
#define REG_FIXED_GX (PMOD_NAV_BASE + 44)
#define REG_FIXED_GY (PMOD_NAV_BASE + 48)
#define REG_FIXED_GZ (PMOD_NAV_BASE + 52)
#define REG_FIXED_TP (PMOD_NAV_BASE + 56)

void print_fixed_value(char* label, u32 raw_val, char* unit) {
    int is_minus = (raw_val >> 31) & 0x01;
    int integer  = (raw_val >> 16) & 0x7FFF;
    u32 fraction = raw_val & 0xFFFF;

    // 16bitの小数値を2桁の10進数に変換
    int decimal = (fraction * 10000) >> 16;

    printf("%s: %c%d.%04d%s  ", label, (is_minus ? '-' : '+'), integer, decimal, unit);
}

int main() {
    init_platform();

    printf("--- Pmod NAV PL-Computed Value Monitor ---\r\n");

    while(1) {
        // PLから全軸読み出し（警告が出ないようすべて使用）
        u32 ax = Xil_In32(REG_FIXED_AX);
        u32 ay = Xil_In32(REG_FIXED_AY);
        u32 az = Xil_In32(REG_FIXED_AZ);
        u32 gx = Xil_In32(REG_FIXED_GX);
        u32 gy = Xil_In32(REG_FIXED_GY);
        u32 gz = Xil_In32(REG_FIXED_GZ);
        u32 tp = Xil_In32(REG_FIXED_TP);

        // コンソール表示
        print_fixed_value("AX", ax, "g");
        print_fixed_value("AY", ay, "g");
        print_fixed_value("AZ", az, "g");
        printf("| ");
        print_fixed_value("GX", gx, "dps");
        print_fixed_value("GY", gy, "dps");
        print_fixed_value("GZ", gz, "dps");
        printf("| ");
        print_fixed_value("TMP", tp, "C");

        printf("\r");

        usleep(100000);
    }

    cleanup_platform();
    return 0;
}
