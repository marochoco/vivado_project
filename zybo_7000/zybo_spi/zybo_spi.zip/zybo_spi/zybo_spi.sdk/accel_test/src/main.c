#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "xil_io.h"

// 自作IPのベースアドレス（xparameters.hで定義されている名前に合わせてください）
#define ACCEL_IP_BASE XPAR_ACCEL_SPI_IP_0_S00_AXI_BASEADDR

int main()
{
    init_platform();
    print("--- ADXL345 Acceleration Monitor ---\n\r");

    while(1) {
        // slv_reg0 (OFFSET 0) から加速度データ(16bit)を読み出す
        uint32_t raw_data = Xil_In32(ACCEL_IP_BASE + 0);

        // slv_reg1 (OFFSET 4) から符号ビット(is_minus)を読み出す
        uint32_t is_minus = Xil_In32(ACCEL_IP_BASE + 4);

        int16_t accel_x = (int16_t)(raw_data & 0xFFFF);

        // 符号を考慮して表示（2の補数処理はハードウェア側で概ね完了していますが、確認用）
        printf("X-Raw: %d | Negative: %s \r", accel_x, is_minus ? "Yes" : "No ");

        // 少し待機
        for(int i=0; i<1000000; i++);
    }

    cleanup_platform();
    return 0;
}
